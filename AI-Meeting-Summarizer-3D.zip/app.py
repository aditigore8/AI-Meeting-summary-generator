import os, json, uuid, subprocess, webbrowser
from pathlib import Path
from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from openai import OpenAI
import yt_dlp

load_dotenv()
app = Flask(__name__)
UPLOAD_FOLDER = Path("downloads")
UPLOAD_FOLDER.mkdir(exist_ok=True)
app.config["MAX_CONTENT_LENGTH"] = 500 * 1024 * 1024

api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise RuntimeError("OPENAI_API_KEY is missing. Create .env from .env.example and add your key.")

client = OpenAI(api_key=api_key)
TEXT_MODEL = os.getenv("TEXT_MODEL", "gpt-5.6-luna")
TRANSCRIPTION_MODEL = os.getenv("TRANSCRIPTION_MODEL", "gpt-4o-transcribe")

@app.route("/")
def home():
    return render_template("index.html")

def analyze_transcript(transcript):
    prompt = f"""You are an AI Meeting Intelligence Orchestrator.
Analyze this meeting transcript. Do not invent information.
Return ONLY valid JSON:
{{
 "summary":"concise executive summary",
 "key_points":["point 1","point 2"],
 "decisions":["decision 1"],
 "action_items":[{{"task":"task","owner":"person or Not specified","deadline":"deadline or Not specified"}}],
 "unresolved_issues":["issue"],
 "topics":["topic"]
}}
TRANSCRIPT:
{transcript}"""
    r = client.responses.create(model=TEXT_MODEL, input=prompt)
    text = r.output_text.strip().replace("```json", "").replace("```", "").strip()
    return json.loads(text)

def transcribe(path):
    with open(path, "rb") as f:
        r = client.audio.transcriptions.create(model=TRANSCRIPTION_MODEL, file=f)
    return r.text

def extract_audio(path):
    out = path.with_suffix(".mp3")
    subprocess.run(["ffmpeg","-y","-i",str(path),"-vn","-acodec","libmp3lame","-q:a","4",str(out)],
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    return out

def download_url(url):
    name = str(uuid.uuid4())
    template = str(UPLOAD_FOLDER / f"{name}.%(ext)s")
    opts = {"format":"bestaudio/best","outtmpl":template,"noplaylist":True,"quiet":True,"no_warnings":True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        return Path(ydl.prepare_filename(info))

@app.post("/api/analyze-transcript")
def api_transcript():
    try:
        transcript = (request.get_json() or {}).get("transcript","").strip()
        if not transcript: return jsonify(success=False,error="Transcript is empty."),400
        return jsonify(success=True, transcript=transcript, result=analyze_transcript(transcript))
    except Exception as e:
        return jsonify(success=False,error=str(e)),500

@app.post("/api/analyze-file")
def api_file():
    try:
        f = request.files.get("file")
        if not f or not f.filename: return jsonify(success=False,error="No file selected."),400
        ext = Path(f.filename).suffix.lower()
        allowed = {".mp3",".wav",".m4a",".aac",".ogg",".flac",".mp4",".mov",".avi",".mkv",".webm"}
        if ext not in allowed: return jsonify(success=False,error="Unsupported file type."),400
        path = UPLOAD_FOLDER / f"{uuid.uuid4()}{ext}"
        f.save(path)
        if ext in {".mp4",".mov",".avi",".mkv",".webm"}: path = extract_audio(path)
        transcript = transcribe(path)
        return jsonify(success=True, transcript=transcript, result=analyze_transcript(transcript))
    except Exception as e:
        return jsonify(success=False,error=str(e)),500

@app.post("/api/analyze-url")
def api_url():
    try:
        url = (request.get_json() or {}).get("url","").strip()
        if not url: return jsonify(success=False,error="URL is empty."),400
        path = download_url(url)
        if path.suffix.lower() in {".mp4",".mov",".avi",".mkv",".webm"}: path = extract_audio(path)
        transcript = transcribe(path)
        return jsonify(success=True, source_url=url, transcript=transcript, result=analyze_transcript(transcript))
    except Exception as e:
        return jsonify(success=False,error=str(e)),500

if __name__ == "__main__":
    port = 5000
    try: webbrowser.open(f"http://127.0.0.1:{port}")
    except Exception: pass
    app.run(host="127.0.0.1", port=port, debug=True, use_reloader=False)
